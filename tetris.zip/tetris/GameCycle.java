package cycle;
import board.Board;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class GameCycle implements ActionListener{
    private Board myBoard;
    private int indice;
    public int getindice(){
        return this.indice;
    }
    public void setindice(int id){
        this.indice=id;
    }
    public GameCycle(Board b,int id){
        setmyBoard(b);
        setindice(id);
    }
    public Board getmyBoard(){
        return this.myBoard;
    }
    public void setmyBoard(Board bo){
        this.myBoard=bo;
    }
    public GameCycle(Board b){
        setmyBoard(b);
    }
    public void actionPerformed(ActionEvent e) {
        try{
            this.getmyBoard().doGameCycle(getindice());
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }
} 