package board;

import joueur.Joueur;
import forme.Forme.Tetrominoe;
import forme.Forme;
import cycle.GameCycle;
import event.TetrisEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;
import java.sql.*;
import fonction.Fonction;
import connection.*;
public class Board extends JPanel{
    private final int BOARD_WIDTH = 20;
    private final int BOARD_HEIGHT = 22;
    private final int PERIOD_INTERVAL = 300;
    private Timer[] timer=new Timer[2];
    private boolean[] isFallingFinished = new boolean[2];
    private boolean isPaused = false;
    private boolean[] canChoose=new boolean[2];
    private int[] numLinesRemoved = new int[2];
    private int[] curX = new int[2];
    private int[] curY = new int[2];
    private JLabel[] statusbar=new JLabel[2];
    private Joueur[] curPiece=new Joueur[2];
    private Tetrominoe[] board;
    public int[] getnumLinesRemoved(){
        return this.numLinesRemoved;
    }
    public int[] getcurX(){
        return this.curX;
    }
    public int[] getcurY(){
        return this.curY;
    }
    public boolean[] getcanChoose(){
        return this.canChoose;
    }
    public void setisPaused(boolean b){
        this.isPaused=b;
    }
    public boolean getisPaused(){
        return this.isPaused;
    }
    public boolean[] getisFallingFinished(){
        return this.isFallingFinished;
    }
    public Timer[] gettimer(){
        return this.timer;
    }
    public void setTimer(Timer[] t){
        this.timer=t;
    }
    public Joueur[] getcurPiece(){
        return this.curPiece;
    }
    public void setcurPiece(Joueur [] joueur){
        this.curPiece=joueur;
    }
    public int squareWidth() {

        return (int) getSize().getWidth() / BOARD_WIDTH;
    }

    public int squareHeight() {

        return (int) getSize().getHeight() / BOARD_HEIGHT;
    }

    public Tetrominoe shapeAt(int x, int y) {

        return board[(y * BOARD_WIDTH) + x];
    }
    public void removeFullLines(int indice) throws Exception{

        int numFullLines = 0;

        for (int i = BOARD_HEIGHT - 1; i >= 0; i--) {

            boolean lineIsFull = true;

            for (int j = 0; j < BOARD_WIDTH; j++) {

                if (shapeAt(j, i) == Tetrominoe.NoShape) {

                    lineIsFull = false;
                    break;
                }
            }

            if (lineIsFull) {

                numFullLines++;

                for (int k = i; k < BOARD_HEIGHT - 1; k++) {
                    for (int j = 0; j < BOARD_WIDTH; j++) {
                        board[(k * BOARD_WIDTH) + j] = shapeAt(j, k + 1);
                    }
                }
            }
        }

        if (numFullLines > 0) {

            numLinesRemoved[indice] += numFullLines;
            Connectionsql conn=new Connectionsql();
            Connection con=conn.getConnection();
            curPiece[indice].setmyPoints(numLinesRemoved[indice]);
            Fonction.update(curPiece[indice],"JOUEUR","idJoueur",con);
            statusbar[indice].setText(String.valueOf(numLinesRemoved[indice]));
             isFallingFinished[indice] = true;
            curPiece[indice].getmyPiece().setForme(Tetrominoe.NoShape);
            con.commit();
            con.close();
        }
    }
    public void pieceDropped(int indice) throws Exception{

        for (int i = 0; i < 5; i++) {

            int x = curX[indice] + curPiece[indice].getmyPiece().x(i);
            int y = curY[indice] - curPiece[indice].getmyPiece().y(i);
            board[(y * BOARD_WIDTH) + x] = curPiece[indice].getmyPiece().getformePiece();
        }

        removeFullLines(indice);

        if (!isFallingFinished[indice]) {
             timer[indice].stop();
            canChoose[indice]=true;
            // newPiece(test,indice);
        }
    }
    public void pause() {

        isPaused = !isPaused;

        if (isPaused) {

            statusbar[0].setText("paused");
            statusbar[1].setText("paused");
        } else {

            statusbar[0].setText(String.valueOf(numLinesRemoved[0]));
            statusbar[1].setText(String.valueOf(numLinesRemoved[1]));
        }

        repaint();
    }
    public boolean tryMove(Forme newPiece, int newX, int newY,int indice) {

        for (int i = 0; i < 4; i++) {

            int x = newX + newPiece.x(i);
            int y = newY - newPiece.y(i);

            if (x < 0 || x >= BOARD_WIDTH || y < 0 || y >= BOARD_HEIGHT) {

                return false;
            }

            if (shapeAt(x, y) != Tetrominoe.NoShape) {

                return false;
            }
        }

        curPiece[indice].setmyPiece(newPiece);
        curX[indice] = newX;
        curY[indice] = newY;

        repaint();

        return true;
    }
    public void dropDown(int indice) throws Exception{

        int newY = curY[indice];

        while (newY > 0) {

            if (!tryMove(curPiece[indice].getmyPiece(), curX[indice], newY - 1,indice)) {

                break;
            }

            newY--;
        }

        pieceDropped(indice);
    }
    public void oneLineDown(int indice) throws Exception{

        if (!tryMove(curPiece[indice].getmyPiece(), curX[indice], curY[indice] - 1,indice)) {
                pieceDropped(indice);

           // isFallingFinished[indice]=true;
        }
    }
    public void clearBoard() {

        for (int i = 0; i < BOARD_HEIGHT * BOARD_WIDTH; i++) {

            board[i] = Tetrominoe.NoShape;
        }
    }
    public void update(int indice) throws Exception{
      
        if (isPaused) {

            return;
        }

        if (isFallingFinished[indice]) {
            //isFallingFinished[indice] = false;
            canChoose[indice]=true;
            //newPiece(test,indice);
            
        } 
        else {

            oneLineDown(indice);
        }
    }
    public void newPiece(Forme piece,int indice) {
        curPiece[indice].setmyPiece(piece);
        if(indice==0){
           
            curX[indice] = BOARD_WIDTH / 4 + 1;
            curY[indice] = BOARD_HEIGHT - 1 + curPiece[indice].getmyPiece().minY();
          
        }
        else if(indice==1){
            curX[indice] = BOARD_WIDTH / 2 + BOARD_WIDTH / 4 + 1;
            curY[indice] = BOARD_HEIGHT - 1 + curPiece[indice].getmyPiece().minY();
          
        }
         if (!tryMove(curPiece[indice].getmyPiece(), curX[indice], curY[indice],indice)) {
                curPiece[indice].getmyPiece().setForme(Tetrominoe.NoShape);
                timer[indice].stop();
                String msg = String.format("Game over. Score: %d", numLinesRemoved[indice]);
               statusbar[indice].setText(msg);
        }        
    }
    public void doGameCycle(int indice) throws Exception{

        update(indice);
        repaint();
    }
    public void initBoard(){
        this.statusbar[0]=new JLabel("");
        this.statusbar[1]=new JLabel("");
        this.canChoose[0]=true;
        this.canChoose[1]=true;
        this.curX[0]=0;
        this.curX[1]=0;
        this.curY[0]=0;
        this.curY[1]=0;
        this.isFallingFinished[0]=false;
        this.isFallingFinished[1]=false;
        this.numLinesRemoved[0]=0;
        this.numLinesRemoved[1]=0;
        this.setBounds(0,0,285,350);
        setFocusable(true);
         addKeyListener(new TetrisEvent(this));
        //statusbar = parent.getStatusBar();
       // addKeyListener(new TAdapter());
    }
    public void doDrawing(Graphics g) {

        Dimension size = getSize();
        int boardTop = (int) size.getHeight() - BOARD_HEIGHT * squareHeight();

        for (int i = 0; i < BOARD_HEIGHT; i++) {

            for (int j = 0; j < BOARD_WIDTH; j++) {

                Tetrominoe shape = shapeAt(j, BOARD_HEIGHT - i - 1);

                if (shape != Tetrominoe.NoShape) {

                    drawSquare(g, j * squareWidth(),
                            boardTop + i * squareHeight(), shape);
                }
            }
        }

        if (curPiece[0].getmyPiece().getformePiece() != Tetrominoe.NoShape) {

            for (int i = 0; i < 5; i++) {

                int x = curX[0] + curPiece[0].getmyPiece().x(i);
                int y = curY[0] - curPiece[0].getmyPiece().y(i);

                drawSquare(g, x * squareWidth(),
                        boardTop + (BOARD_HEIGHT - y - 1) * squareHeight(),
                        curPiece[0].getmyPiece().getformePiece());
            }
        }

        
        if (curPiece[1].getmyPiece().getformePiece() != Tetrominoe.NoShape) {
            
            for (int i = 0; i < 5; i++) {

                int x = curX[1] + curPiece[1].getmyPiece().x(i);
                int y = curY[1] - curPiece[1].getmyPiece().y(i);
                drawSquare(g, x * squareWidth(),
                        boardTop + (BOARD_HEIGHT - y - 1) * squareHeight(),
                        curPiece[1].getmyPiece().getformePiece());
            }
        }
    }

    public void drawSquare(Graphics g, int x, int y, Tetrominoe shape) {

        Color colors[] = {new Color(0, 0, 0), new Color(204, 102, 102),
                new Color(102, 204, 102), new Color(102, 102, 204),
                new Color(204, 204, 102), new Color(204, 102, 204),
                new Color(102, 204, 204), new Color(218, 170, 0) ,new Color(218, 170, 0)
        };

        Color color = colors[shape.ordinal()];

        g.setColor(color);
        g.fillRect(x + 1, y + 1, squareWidth() - 2, squareHeight() - 2);

        g.setColor(color.brighter());
        g.drawLine(x, y + squareHeight() - 1, x, y);
        g.drawLine(x, y, x + squareWidth() - 1, y);

        g.setColor(color.darker());
        g.drawLine(x + 1, y + squareHeight() - 1,
                x + squareWidth() - 1, y + squareHeight() - 1);
        g.drawLine(x + squareWidth() - 1, y + squareHeight() - 1,
                x + squareWidth() - 1, y + 1);
    }
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        doDrawing(g);
    }
    public Board() {
        initBoard();
    }
    public void start() {
      
        Forme test=new Forme();
        board = new Tetrominoe[BOARD_WIDTH * BOARD_HEIGHT];
        test.setForme(Tetrominoe.NoShape);
        clearBoard();
        timer[0] = new Timer(PERIOD_INTERVAL, new GameCycle(this,0));
        timer[1] = new Timer(PERIOD_INTERVAL, new GameCycle(this,1));
       

       newPiece(test,0);
        newPiece(test,1);
        timer[0].stop();
        timer[1].stop();
    }

}




