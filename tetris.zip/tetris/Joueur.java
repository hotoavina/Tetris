package joueur;
import forme.Forme;
public class Joueur{
    private Forme myPiece;
    private String idJoueur;
    private String nom;
    private Integer myPoints;
    public String getidJoueur(){
        return this.idJoueur;
    }
    public void setidJoueur(String id){
        this.idJoueur=id;
    }
    public String getnom(){
        return this.nom;
    }
    public void setnom(String n){
        this.nom=nom;
    }
    public Forme getmyPiece(){
        return this.myPiece;
    }
    public Integer getmyPoints(){
        return this.myPoints;
    }
    public void setmyPiece(Forme piece){
        this.myPiece=piece;
    }
    public void setmyPoints(Integer add){
        this.myPoints=add;
    }

}