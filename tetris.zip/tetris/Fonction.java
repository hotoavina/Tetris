package fonction;
import connection.*;
import java.sql.*;
import java.util.Date;
import concatenage.*;
import java.lang.reflect.Field;
import java.io.*;
import java.text.*;
import java.util.Vector;
import java.util.Date;
import java.math.BigDecimal;
import java.lang.Object;
import java.lang.reflect.Method;
public class Fonction{
    //Creer un objet a partir d'un formulaire
     public static Object objectForInsertion(String[] donnees,Object o,String [] attr) throws Exception
    {
        for(int i=0;i<attr.length;i++)
        {
               for(int ii=0;ii<o.getClass().getMethods().length;ii++){
                        if(o.getClass().getMethods()[ii].getName().equalsIgnoreCase("set"+attr[i])==true){
                            if(donnees[i]!=null){

                                    if(o.getClass().getDeclaredFields()[i].getGenericType().getTypeName().equalsIgnoreCase(attr[0].getClass().getName())==true){
                                        o.getClass().getMethods()[ii].invoke(o,donnees[i]);
                                    }
                                    else if(o.getClass().getDeclaredFields()[i].getGenericType().getTypeName().equalsIgnoreCase("int")==true){
                                        o.getClass().getMethods()[ii].invoke(o,Integer.parseInt(donnees[i]));
                                    }
                                    else if(o.getClass().getDeclaredFields()[i].getGenericType().getTypeName().equalsIgnoreCase("double")==true){
                                        o.getClass().getMethods()[ii].invoke(o,Double.parseDouble(donnees[i]));
                                    }
                                    else if(o.getClass().getDeclaredFields()[i].getGenericType().getTypeName().equalsIgnoreCase("java.lang.Integer")==true){
                                    
                                            o.getClass().getMethods()[ii].invoke(o,new Integer(donnees[i]));
                                        
                                    }
                                    else if(o.getClass().getDeclaredFields()[i].getGenericType().getTypeName().equalsIgnoreCase("java.lang.Double")==true){
                                    
                                                o.getClass().getMethods()[ii].invoke(o,new Double(donnees[i]));
                                    
                                    
                                    }
                            }
                        }
                    }
        }
        Object newO=o;
        return newO;
    }
    //PRENDRE LES COLONNE NON NULL
    public static String [] getColumnNotNull(Object o,String tableName,Connection con) throws Exception{
        Field [] lField=o.getClass().getDeclaredFields();
        String [] bCol=Fonction.columnName(o,tableName,con);
        Vector v=new Vector ();
        for(int iCol=0;iCol<lField.length;iCol++){
            if(Fonction.correspend(lField[iCol].getName(),bCol)){
                    if(o.getClass().getMethod("get"+lField[iCol].getName()).invoke(o)!=null){
                    v.add(lField[iCol].getName());
                }
            }
             
        } 
        String [] data=new String[v.size()];
        for(int i=0;i<data.length;i++){
            data[i]=(String)v.get(i);
        }
        return data;
    }
    //PRENDRE LES DONNEES NON NULL
    public static String [] getValuesNotNUll(Object o,String tableName,Connection con) throws Exception{
        String [] column=Fonction.getColumnNotNull(o,tableName,con);
         Vector v=new Vector ();
        for(int i=0;i<column.length;i++){
            if(o.getClass().getDeclaredField(column[i]).getGenericType().getTypeName().equalsIgnoreCase("java.util.Date")==true){
                    DateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
                    v.add("'"+sdf.format(o.getClass().getMethod("get"+column[i]).invoke(o))+"'");    
            }
            else{
                if(o.getClass().getMethod("get"+column[i]).invoke(o) instanceof Number){
                     v.add(o.getClass().getMethod("get"+column[i]).invoke(o).toString());
                }
                else{
                    v.add("'"+o.getClass().getMethod("get"+column[i]).invoke(o).toString()+"'");
                }
            }
            
           
        }
        String [] data=new String[v.size()];
        for(int i=0;i<data.length;i++){
            data[i]=(String)v.get(i);
        }
        return data;

    } 
    //CHECK SI UN OBJET EST VIDE
    public static boolean isEmpty(Object o,String tableName,Connection con) throws Exception{
        Field [] lField=o.getClass().getDeclaredFields();
        String [] col=Fonction.columnName(o,tableName,con);
        int counter=0;
        for(int i=0;i<col.length;i++){
            if(o.getClass().getMethod("get"+col[i]).invoke(o)==null){
                counter++;
            }
        }
        if(counter==col.length){
            return true;
        }
        else{
            return false;
        }
    }
    //PREND L'INDICE CORRESPONDANT A LA METHODE
    public static int getIdMethod(Object lo,String getname){
    for(int i=0;i<lo.getClass().getMethods().length;i++)
        {
           if(lo.getClass().getMethods()[i].getName().equalsIgnoreCase(getname)==true)
           {
                return i;
           } 
        }
      return -1;
    }
    ///FONCTION POUR PRENDRE LES DONNEES D'UN OBJET
  
    ///FONCTION POUR PRENDRE LES ATTRIBUTS D'UN OBJET
    public static String[] getField(Object o,String pKey){
        Field [] lField=o.getClass().getDeclaredFields();
        Vector v=new Vector ();
        for(int iCol=0;iCol<lField.length;iCol++){
             if(lField[iCol].getName().equalsIgnoreCase(pKey)==true){
                 continue;
             }
            v.add(lField[iCol].getName());
        } 
        String [] data=new String[v.size()];
        for(int i=0;i<data.length;i++){
            data[i]=(String)v.get(i);
        }
        return data;
    }
    //nom de colonne d'une table
    public static String [] columnName(Object o,String nomdeTable,Connection con) throws Exception{
        Field [] lField=o.getClass().getDeclaredFields();
        String request="SELECT * FROM "+nomdeTable;
        java.sql.Statement stmt = con.createStatement(); 
        ResultSet rs = stmt.executeQuery(request);
        ResultSetMetaData rsmd = rs.getMetaData();
        int numberOfColumns = rsmd.getColumnCount();
        String [] column=new String[numberOfColumns];
        for(int i=0;i<column.length;i++){
            column[i]=rsmd.getColumnName(i+1);
             
        }
        int ind=0;
        Vector val=new Vector();
        while(ind!=numberOfColumns){
            for(int j=0;j<lField.length;j++){
                if(lField[j].getName().equalsIgnoreCase(column[ind])==true){
                    val.add(lField[j].getName());
                }
            }
            ind++;
        }
        String [] finale=new String[val.size()];
        for(int iv=0;iv<finale.length;iv++){
            finale[iv]=(String)val.get(iv);
          
        }
        return finale;
    }
      public static String[] getData(Object o,String tableName,String pKey,Connection con) throws Exception{
        String [] lField=Fonction.columnName(o,tableName,con);
        Vector v=new Vector ();
        for(int iCol=0;iCol<lField.length;iCol++){
             if(lField[iCol].equalsIgnoreCase(pKey)==true || o.getClass().getMethod("get"+lField[iCol]).invoke(o)==null){
                 continue;
             }
             else if(o.getClass().getMethod("get"+lField[iCol]).invoke(o) instanceof Number){
                    v.add(o.getClass().getMethod("get"+lField[iCol]).invoke(o).toString());
                }
             else{
                if(o.getClass().getDeclaredField(lField[iCol]).getGenericType().getTypeName().equalsIgnoreCase("java.util.Date")==true){
                    DateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
                    v.add("'"+sdf.format(o.getClass().getMethod("get"+lField[iCol]).invoke(o))+"'");    
                }
                else
                {
                    v.add("'"+o.getClass().getMethod("get"+lField[iCol]).invoke(o).toString()+"'");
                }
                 
            }
            
           
        } 
        String [] data=new String[v.size()];
        for(int i=0;i<data.length;i++){
            data[i]=(String)v.get(i);
        }
        return data;
    }
    ///FONCTION INSERT POUR INSERER DANS LA BASE
    public static void insert(Object o,String tableName,String pKey,Connection con) throws Exception{
        String [] data=Fonction.getData(o,tableName,pKey,con);
        String [] col=Fonction.columnName(o,tableName,con);
        String colonne=Concat.strcatV(col);
        String dataToInsert=Concat.strcatV(data);
        String sequence="";
        if(con.getClass().getName().equalsIgnoreCase("oracle.jdbc.driver.T4CConnection")){
            sequence="s_"+pKey+".nextval";
        }
        else{
            sequence="nextval('s_"+pKey+"')";
        }
        String request="INSERT INTO "+tableName+"("+colonne+") VALUES('"+tableName.toUpperCase()+"_'||"+sequence+","+dataToInsert+")";
        java.sql.Statement stmt = con.createStatement(); 
        stmt.execute(request);
        System.out.print(request);
              
    }
    ///MISE A JOUR
    public static void update(Object o,String tableName,String pKey,Connection con) throws Exception{
        String [] data=Fonction.getData(o,tableName,pKey,con);
        Vector fields=new Vector();
        Vector dataes=new Vector();
        String idValue=o.getClass().getMethod("get"+pKey).invoke(o).toString();
        String [] col=Fonction.getColumnNotNull(o,tableName,con);
        String [] column=new String[col.length-1];
        for(int i=0;i<col.length;i++){
            
            if(col[i].equalsIgnoreCase(pKey)==true){
                continue;
            }
            else{
                 
                fields.add(col[i]);
            }
        }
        for(int j=0;j<fields.size();j++){
            column[j]=(String)fields.get(j);
           

        }
        String settable=Concat.strcatWithEqual(column,data,"=",",");
       String request="UPDATE "+tableName+" SET "+settable+" WHERE "+pKey+"='"+idValue+"'";
       System.out.println(request);
        java.sql.Statement stmt = con.createStatement(); 
        ResultSet rs=stmt.executeQuery(request);
    }
    //Fonction mijery field mcorrespondre
    public static boolean correspend(String ray,String [] liste){
        int counter=0;
            for(int i=0;i<liste.length;i++){
                if(ray.equalsIgnoreCase(liste[i])==true){
                    counter ++;
                }
            }
            if(counter==0){
                return false;
            }
            else{
                return true;
            }
    }
    public static int idcorrespend(String ray,String [] liste){
        int indice=0;
            for(int i=0;i<liste.length;i++){
                if(ray.equalsIgnoreCase(liste[i])==true){
                    indice=i;
                }
            }
        return indice;
    }
    //FONCTION SELECT
    public static Object[] select(Object filtre,String tableName,Connection con) throws Exception{
        java.sql.Statement stmt = con.createStatement();
        Vector valiny=new Vector();
        String [] col=Fonction.columnName(filtre,tableName,con);
        Field [] lField=filtre.getClass().getDeclaredFields();
        String request="";
        
        if(Fonction.isEmpty(filtre,tableName,con)==true){
           request="SELECT * FROM "+tableName;
          
        }
        else{
            String [] column=Fonction.getColumnNotNull(filtre,tableName,con);
            String [] data=Fonction.getValuesNotNUll(filtre,tableName,con);
            String [] newdata=new String[data.length];
            for(int ind=0;ind<newdata.length;ind++){
                newdata[ind]=data[ind];
               
            }
            String filter=Concat.strcatWithEqual(column,newdata,"="," AND ");
            request="SELECT * FROM "+tableName+" WHERE "+filter;
        }
    
        ResultSet rs=stmt.executeQuery(request);
            while(rs.next())
            {
                 
                Object tempo=filtre.getClass().newInstance();
                
                    for(int i=0;i<lField.length;i++)
                    {
                      
                    if(Fonction.correspend(lField[i].getName(),col)==true){
                           
                           int corresp=Fonction.idcorrespend(lField[i].getName(),col);
                        if(con.getClass().getName().equalsIgnoreCase("oracle.jdbc.driver.T4CConnection")){

                                    if(lField[i].getGenericType().getTypeName().equalsIgnoreCase("java.lang.Integer")==true){
                                       
                                        BigDecimal test=(BigDecimal)rs.getObject(corresp+1);
                                        int indice=Fonction.getIdMethod(filtre,"set"+lField[i].getName());
                                        tempo.getClass().getMethods()[indice].invoke(tempo,new Integer(test.intValue()));

                                    }
                                    else if(lField[i].getGenericType().getTypeName().equalsIgnoreCase("int")==true){
                                       
                                        BigDecimal test=(BigDecimal)rs.getObject(corresp+1);
                                        int indice=Fonction.getIdMethod(filtre,"set"+lField[i].getName());
                                        tempo.getClass().getMethods()[indice].invoke(tempo,test.intValue());

                                    }
                                    else if(lField[i].getGenericType().getTypeName().equalsIgnoreCase("double")==true){
                                       
                                        BigDecimal test=(BigDecimal)rs.getObject(corresp+1);
                                        int indice=Fonction.getIdMethod(filtre,"set"+lField[i].getName());
                                        tempo.getClass().getMethods()[indice].invoke(tempo,test.doubleValue());

                                    }
                                    else if(lField[i].getGenericType().getTypeName().equalsIgnoreCase("java.lang.Double")==true){
                                       
                                        BigDecimal test=(BigDecimal)rs.getObject(corresp+1);
                                        int indice=Fonction.getIdMethod(filtre,"set"+lField[i].getName());
                                        tempo.getClass().getMethods()[indice].invoke(tempo,new Double(test.doubleValue()));

                                    }
                                    else if(lField[i].getGenericType().getTypeName().equalsIgnoreCase("java.util.Date")==true){
                                             int indice=Fonction.getIdMethod(filtre,"set"+lField[i].getName());
                                            tempo.getClass().getMethods()[indice].invoke(tempo,rs.getObject(corresp+1));
                                    }
                                    else{

                                       
                                        tempo.getClass().getMethod("set"+lField[i].getName(),rs.getObject(corresp+1).getClass()).invoke(tempo,rs.getObject(corresp+1));
                                        
                                    }
                        
                                }
                                else{
                            
                                    tempo.getClass().getMethod("set"+lField[i].getName(),rs.getObject(corresp+1).getClass()).invoke(tempo,rs.getObject(corresp+1));
                                }
                                
                    }
                    }
                
                valiny.add(tempo); 
            }
            
        return valiny.toArray();
    }
    public static int getIndiceMax(int [] tab){
        int max=0;
        for(int i=0;i<tab.length;i++){
            if(tab[i]>tab[max]){
                max=i;
            }
        }
        return max;
    }
    public static double getSomme(Object [] lo,String getname) throws Exception{
        double temp=0;
    
        for(int i=0;i<lo.length;i++)
        {
           int indice=Fonction.getIdMethod(lo[i],getname);
           Method m=lo[i].getClass().getMethods()[indice];     
            
             if(m.getReturnType().getName().equalsIgnoreCase(getname.getClass().getName())==true)
                {
                    temp=0;
                } 
                else
                {
                      
                        if(m.getReturnType().getName().equalsIgnoreCase("int")==true)
                        {
                            double d1=(int)m.invoke(lo[i]);
                            temp=temp+d1;
                        }
                        else
                        {
                            double d=(double)m.invoke(lo[i]);
                            temp=temp+d;
                        }
                    
                }     
        }
        return temp;
    }

    
}