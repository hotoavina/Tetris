package right;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;

public class  ChooseBarRight  extends JPanel {

       public ChooseBarRight() {

        initChooseBar();
    }

    private void initChooseBar() {
        this.setLayout(null);
        this.setBounds(285,0,350,350);
         JLabel [] key=new JLabel[14];
        key[0]=new JLabel("SHIFT");
        key[0].setBounds(65,25,75,25);
        key[1]=new JLabel("ENTER");
        key[1].setBounds(65,65,75,25);
        key[2]=new JLabel("M");
        key[2].setBounds(65,105,25,25);
        key[3]=new JLabel("O");
        key[3].setBounds(65,165,25,25);
        key[4]=new JLabel("P");
        key[4].setBounds(65,205,25,25);
        key[5]=new JLabel("K");
        key[5].setBounds(65,245,25,25);
        key[6]=new JLabel("N");
        key[6].setBounds(65,295,25,25);
        

        key[7]=new JLabel("A");
        key[7].setBounds(175,25,25,25);
        key[8]=new JLabel("E");
        key[8].setBounds(175,65,25,25);
        key[9]=new JLabel("R");
        key[9].setBounds(175,105,25,25);
        key[10]=new JLabel("W");
        key[10].setBounds(175,165,25,25);
        key[11]=new JLabel("T");
        key[11].setBounds(175,205,25,25);
        key[12]=new JLabel("X");
        key[12].setBounds(175,245,25,25);
        key[13]=new JLabel("C");
        key[13].setBounds(175,295,25,25);

        for(int i=0;i<14;i++){
            this.add(key[i]);
        }
       // this.add(new JLabel("test"));
        setFocusable(true);
    }
    
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        g.drawLine(0,0,0,350);
        this.doDrawing(g);
    }

    public  void doDrawing(Graphics g) {
       
        
        ChooseBarRight.drawSquare(g,1,25,25);
        ChooseBarRight.drawSquare(g,1,35,25);
        ChooseBarRight.drawSquare(g,1,35,35);
        ChooseBarRight.drawSquare(g,1,45,35);

        ChooseBarRight.drawSquare(g,2,45,65);
        ChooseBarRight.drawSquare(g,2,35,65);
        ChooseBarRight.drawSquare(g,2,35,75);
        ChooseBarRight.drawSquare(g,2,25,75);

        ChooseBarRight.drawSquare(g,3,25,105);
        ChooseBarRight.drawSquare(g,3,25,115);
        ChooseBarRight.drawSquare(g,3,25,125);
        ChooseBarRight.drawSquare(g,3,25,135);

        ChooseBarRight.drawSquare(g,5,25,165);
        ChooseBarRight.drawSquare(g,5,35,165);
        ChooseBarRight.drawSquare(g,5,25,175);
        ChooseBarRight.drawSquare(g,5,35,175); 

        ChooseBarRight.drawSquare(g,4,25,205);
        ChooseBarRight.drawSquare(g,4,35,205);
        ChooseBarRight.drawSquare(g,4,35,215);
        ChooseBarRight.drawSquare(g,4,45,205);    

        ChooseBarRight.drawSquare(g,6,25,245);
        ChooseBarRight.drawSquare(g,6,25,255);
        ChooseBarRight.drawSquare(g,6,25,265);
        ChooseBarRight.drawSquare(g,6,35,265);      
       
        
        ChooseBarRight.drawSquare(g,7,25,295);
        ChooseBarRight.drawSquare(g,7,25,305);
        ChooseBarRight.drawSquare(g,7,25,315);
        ChooseBarRight.drawSquare(g,7,15,315);
        
    }
    public static void drawSquare(Graphics g, int indice,int x,int y) {

        Color colors[] = {new Color(0, 0, 0), new Color(204, 102, 102),
                new Color(102, 204, 102), new Color(102, 102, 204),
                new Color(204, 204, 102), new Color(204, 102, 204),
                new Color(102, 204, 204), new Color(218, 170, 0)
        };

        Color color = colors[indice];

        g.setColor(color);
        g.fillRect(x + 1, y + 1, 10, 10);

        g.setColor(color.brighter());
        g.drawLine(x, y + 9, x, y);
        g.drawLine(x, y, x + 9, y);

        g.setColor(color.darker());
        g.drawLine(x + 1,y+ 9,
                x + 9, y + 9);
        g.drawLine(x + 9, y + 9,
                x + 9, y + 1);

          
    }

}
