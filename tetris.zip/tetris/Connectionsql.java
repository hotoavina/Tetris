
package connection;
import java.sql.*;
public class Connectionsql{
	public Connection getConnection() throws Exception
	{
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connectionSQL = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:base","tetris","1234");
			connectionSQL.setAutoCommit(false);
		
		return connectionSQL;
	}
}