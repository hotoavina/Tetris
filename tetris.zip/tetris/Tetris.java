package tetris;

import board.Board;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import right.*;
import joueur.Joueur;



public class Tetris extends JFrame {

    private JLabel statusbar;
    private Board board=new Board();
    public Board getboard(){
        return this.board;
    }
    public void setboard(Board b){
        this.board=b;
    }
  
    public Tetris(Board bo) {
        this.setboard(bo);
        add(this.getboard());
        initUI();
    }

    private void initUI() {
        this.setLayout(null);
        statusbar = new JLabel(" 0");
        statusbar.setBounds(0,350,300,10);
        add(statusbar);
       ChooseBarRight cR=new ChooseBarRight();
        add(cR);

        this.getboard().start();
        setTitle("Tetris");
        setSize(550, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    JLabel getStatusBar() {

        return statusbar;
    }

    public static void main(String[] args) {
            Joueur [] joueur=new Joueur[2];
            joueur[0]=new Joueur();
            joueur[1]=new Joueur();
            joueur[0].setidJoueur("JOUEUR_1");
            joueur[1].setidJoueur("JOUEUR_2");
            Board bo=new Board();
            bo.setcurPiece(joueur);
            Tetris game = new Tetris(bo);
            game.setVisible(true);
    }
}
