package event;
import board.Board;
import forme.Forme.Tetrominoe;
import forme.Forme;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class TetrisEvent extends KeyAdapter {
    private Board board;
    public Board getboard(){
        return this.board;
    }
    public void setboard(Board bo){
        this.board=bo;
    }
    public TetrisEvent(Board b){
        this.setboard(b);
    }
    public void keyPressed(KeyEvent e) {

        // if (this.getboard().getcurPiece()[0].getmyPiece().getformePiece() == Tetrominoe.NoShape || this.getboard().getcurPiece()[1].getmyPiece().getformePiece() == Tetrominoe.NoShape) {

            // return;
         //}

        int keycode = e.getKeyCode();

       
        try{
                    if(keycode==KeyEvent.VK_LEFT){
                    this.getboard().tryMove(this.getboard().getcurPiece()[0].getmyPiece(),this.getboard().getcurX()[0] - 1, this.getboard().getcurY()[0],0);
                }
                else if(keycode==KeyEvent.VK_RIGHT){
                    //tryMove(curPiece, curX + 1, curY);
                    this.getboard().tryMove(this.getboard().getcurPiece()[0].getmyPiece(),this.getboard().getcurX()[0] +1, this.getboard().getcurY()[0],0);
                }
                else if(keycode==KeyEvent.VK_A){
                    this.getboard().tryMove(this.getboard().getcurPiece()[1].getmyPiece(),this.getboard().getcurX()[1] - 1, this.getboard().getcurY()[1],1);
                }
                else if(keycode==KeyEvent.VK_D){
                    //tryMove(curPiece, curX + 1, curY);
                    this.getboard().tryMove(this.getboard().getcurPiece()[1].getmyPiece(),this.getboard().getcurX()[1] +1, this.getboard().getcurY()[1],1);
                }
                
                else if(keycode==KeyEvent.VK_UP){
                
                    this.getboard().tryMove(this.getboard().getcurPiece()[0].getmyPiece().rotateLeft(),this.getboard().getcurX()[0], this.getboard().getcurY()[0],0);
                }
                else if(keycode==KeyEvent.VK_W){
                
                    this.getboard().tryMove(this.getboard().getcurPiece()[1].getmyPiece().rotateLeft(),this.getboard().getcurX()[1], this.getboard().getcurY()[1],1);
                }
                else if(keycode==KeyEvent.VK_DOWN){
                
                    this.getboard().oneLineDown(0);
                }
                else if(keycode==KeyEvent.VK_S){
                
                    this.getboard().oneLineDown(1);
                
                }
                else if(keycode==KeyEvent.VK_SHIFT){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.ZShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_Q){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.ZShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }
                
                else if(keycode==KeyEvent.VK_ENTER){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.SShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_E){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.SShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }

                else if(keycode==KeyEvent.VK_M){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.LineShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_R){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.LineShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }
                

                else if(keycode==KeyEvent.VK_P){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.TShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_T){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.TShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }

                

                else if(keycode==KeyEvent.VK_O){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.SquareShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_Z){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.SquareShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }

                

                else if(keycode==KeyEvent.VK_K){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.LShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_X){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.LShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }

                else if(keycode==KeyEvent.VK_N){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.MirroredLShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();

                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_C){
                    if(this.getboard().getcanChoose()[1]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.MirroredLShape);
                        this.getboard().getcanChoose()[1]=false;
                        this.getboard().newPiece(tempo,1);
                        this.getboard().gettimer()[1].start();
                    }
                    else{
                        return;
                    }
                }
                else if(keycode==KeyEvent.VK_L){
                    if(this.getboard().getcanChoose()[0]==true){
                        Forme tempo=new Forme();
                        tempo.setForme(Tetrominoe.NewShape);
                        this.getboard().getcanChoose()[0]=false;
                        this.getboard().newPiece(tempo,0);
                        this.getboard().gettimer()[0].start();
                    }
                    else{
                        return;
                    }
                }
 
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }                  
}